Libraries for adding WS-* support to ext/soap in PHP.

Currently provides support for employing WS-Security and WS-Addressing when using the native PHP 5 SOAP extension.

The WS-Security library also requires the use of the xmlseclibs library which supports XML-DSIG and XMLENC. 

Mailing List: https://groups.google.com/forum/#!forum/wse-php
